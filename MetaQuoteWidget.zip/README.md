# MetaQuoteWidget

Mobile-first quote widget (PWA) that rotates your quotes, ready for GitHub Pages.

<img src="assets/icons/icon-192.png" alt="icon" width="96" height="96" />

## ✅ Возможности
- Полностью адаптивен (mobile-first), без зума и «щипков»
- Тап/свайп → следующая цитата
- Кнопки: **Копировать**, **Поделиться**
- Редактор для добавления своих цитат (локально в браузере)
- PWA: оффлайн-режим, установка на главный экран
- Готов к деплою на **GitHub Pages**

## 🚀 Быстрый старт (локально)
Открой `index.html` в мобильном браузере (Chrome/Firefox). Для корректной работы PWA рекомендуется запуск через HTTP-сервер.

Простой вариант (Python 3):
```bash
python -m http.server 8080
# затем открой http://localhost:8080
```

## ⬆️ Деплой на GitHub Pages
1. Создай репозиторий **MetaQuoteWidget** (или любое имя).
2. Залей файлы из этого проекта в корень `main`.
3. Включи **Settings → Pages → Deploy from a branch → Branch: main / root**.
   - Либо оставь как есть, GitHub автоматически опубликует `https://<username>.github.io/<repo>/`.
4. Открой сайт на телефоне → **Add to Home Screen** (Добавить на главный экран).

> При первом открытии дождись регистрации Service Worker. Затем сайт будет доступен оффлайн.

## ✍️ Редактирование цитат
- Базовые цитаты лежат в `data/quotes.json`.
- Свои цитаты можно добавлять на странице **Редактор** (`/edit.html`), они сохраняются в `localStorage` и не требуют сервера.

## 🧩 Структура
```
.
├─ assets/
│  └─ icons/                # иконки PWA
├─ data/
│  └─ quotes.json           # базовые цитаты
├─ index.html               # основной экран (виджет)
├─ edit.html                # локальный редактор
├─ script.js                # логика
├─ manifest.webmanifest     # PWA-манифест
├─ sw.js                    # сервис-воркер (оффлайн)
├─ LICENSE
└─ README.md
```

## 🛠️ Дальше по плану
- [ ] Тематические наборы цитат (MetaDiary, MetaPsychology)
- [ ] Таймер «фраза по расписанию» (утро/день/вечер)
- [ ] Экспорт/импорт пользовательских цитат (JSON)
- [ ] APK-обёртка (WebView) для полноценного Android-виджета

---

**Автор**: Andárer & Valerych  
Лицензия: MIT
