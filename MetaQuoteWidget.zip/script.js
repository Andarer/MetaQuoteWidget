const state = {
  quotes: [],
  index: -1,
  userQuotes: [],
  lastIndex: -1
};

const STATUS = document.getElementById('status');
const QUOTE = document.getElementById('quote');
const CARD = document.getElementById('card');
const nextBtn = document.getElementById('nextBtn');
const copyBtn = document.getElementById('copyBtn');
const shareBtn = document.getElementById('shareBtn');

const USER_KEY = 'mqw_user_quotes';

async function loadQuotes(){
  try {
    const res = await fetch('./data/quotes.json', { cache: 'no-store' });
    const json = await res.json();
    state.quotes = (json.quotes || []).filter(Boolean);
  } catch(e){
    state.quotes = [];
  }
  try {
    state.userQuotes = JSON.parse(localStorage.getItem(USER_KEY) || '[]');
  } catch { state.userQuotes = []; }
}

function nextQuote(){
  const pool = [...state.quotes, ...state.userQuotes];
  if(pool.length === 0){
    QUOTE.textContent = 'Нет цитат. Добавь свои через «Редактор».';
    return;
  }
  let idx;
  if (pool.length === 1) idx = 0;
  else {
    do { idx = Math.floor(Math.random() * pool.length); }
    while (idx === state.lastIndex);
  }
  state.lastIndex = idx;
  QUOTE.textContent = pool[idx];
  CARD.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 180, easing: 'ease-out' });
}

function setStatus(text){ STATUS.textContent = text; }

function setupUI(){
  nextBtn.addEventListener('click', nextQuote);
  copyBtn.addEventListener('click', async () => {
    await navigator.clipboard.writeText(QUOTE.textContent);
    setStatus('скопировано');
    setTimeout(() => setStatus('offline-ready'), 1200);
  });
  shareBtn.addEventListener('click', async () => {
    const text = QUOTE.textContent;
    if (navigator.share) {
      try { await navigator.share({ text }); } catch {}
    } else {
      await navigator.clipboard.writeText(text);
    }
    setStatus('поделено');
    setTimeout(() => setStatus('offline-ready'), 1200);
  });
  // keyboard and tap/swipe
  CARD.addEventListener('click', nextQuote);
  CARD.addEventListener('keydown', (e) => { if (e.key === ' ' || e.key === 'Enter' || e.key === 'ArrowRight') nextQuote(); });
  let startX = null;
  CARD.addEventListener('touchstart', (e) => { startX = e.changedTouches[0].clientX; }, {passive:true});
  CARD.addEventListener('touchend', (e) => { 
    if (startX === null) return;
    const dx = e.changedTouches[0].clientX - startX;
    if (Math.abs(dx) > 30) nextQuote();
    startX = null;
  });
}

async function main(){
  setupUI();
  await loadQuotes();
  nextQuote();
}

main();
